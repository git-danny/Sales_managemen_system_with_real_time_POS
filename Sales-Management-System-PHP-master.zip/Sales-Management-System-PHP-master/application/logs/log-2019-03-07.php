<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-03-07 18:28:12 --> Severity: Notice --> Undefined variable: json C:\xampp\htdocs\Sales_System\application\controllers\Home.php 112
