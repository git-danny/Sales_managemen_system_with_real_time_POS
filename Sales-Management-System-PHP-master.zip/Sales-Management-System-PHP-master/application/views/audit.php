<?php
defined('BASEPATH') OR exit('');
?>

<div class="row">
    <div class="col-sm-12">
        <div class="well">
            List of all goods
        </div>
    </div>
</div>